// C++ code
//
int numTable[10][7] = {
      {1, 1, 1, 1, 1, 1, 0}, // เลข 0
      {0, 1, 1, 0, 0, 0, 0}, // เลข 1
      {1, 1, 0, 1, 1, 0, 1}, // เลข 2
      {1, 1, 1, 1, 0, 0, 1}, // เลข 3
      {0, 1, 1, 0, 0, 1, 1}, // เลข 4
      {1, 0, 1, 1, 0, 1, 1}, // เลข 5
      {1, 0, 1, 1, 1, 1, 1}, // เลข 6
      {1, 1, 1, 0, 0, 0, 0}, // เลข 7
      {1, 1, 1, 1, 1, 1, 1}, // เลข 8
      {1, 1, 1, 1, 0, 1, 1}  // เลข 9
    };

int id[8] = {6,8,0,7,0,1,7,4};
int j = 0;

void setup()
{
  pinMode(13, OUTPUT);
  pinMode(12, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(9, OUTPUT);
  pinMode(8, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(2, OUTPUT);

  
}

void display(int ptr[]);

void loop()
{
  for(int i = 0;i < 100;i++){
    digitalWrite(12, 1);
    digitalWrite(13, 0);
    display(numTable[id[j]]);
    delay(5);
    
    digitalWrite(12, 0);
    digitalWrite(13, 1);
    display(numTable[id[j + 1]]);
    delay(5);
  }

  j = (j + 2) % 8;
}

void display(int ptr[]){
  digitalWrite(4, ptr[0]);
  digitalWrite(5, ptr[1]);
  digitalWrite(10, ptr[2]);
  digitalWrite(9, ptr[3]);
  digitalWrite(8, ptr[4]);
  digitalWrite(3, ptr[5]);
  digitalWrite(2, ptr[6]);
}