/*
 *
 * This Arduino UNO R4 code is made available for public use without any restriction
 *
 */

#include <WiFiS3.h>
#include <MQTTClient.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);
int i = 0, j = 0;

const char WIFI_SSID[] = "iPhone";     // CHANGE TO YOUR WIFI SSID
const char WIFI_PASSWORD[] = "12345678";  // CHANGE TO YOUR WIFI PASSWORD

const char MQTT_BROKER_ADRRESS[] = "mqtt-dashboard.com";  // CHANGE TO MQTT BROKER'S ADDRESS
//const char MQTT_BROKER_ADRRESS[] = "192.168.0.11";  // CHANGE TO MQTT BROKER'S IP ADDRESS
const int MQTT_PORT = 1883;
const char MQTT_CLIENT_ID[] = "arduino-uno-r4-clienasdasdasdwdas";  // CHANGE IT AS YOU DESIRE
const char MQTT_USERNAME[] = "";              // CHANGE IT IF REQUIRED, empty if not required
const char MQTT_PASSWORD[] = "";              // CHANGE IT IF REQUIRED, empty if not required

// The MQTT topics that Arduino should publish/subscribe
const char SUBSCRIBE_TOPIC[] = "test/123Hello";  // CHANGE IT AS YOU DESIRE


const int PUBLISH_INTERVAL = 5000;  // 5 seconds

WiFiClient network;
MQTTClient mqtt = MQTTClient(256);

unsigned long lastPublishTime = 0;

void setup() {
  Serial.begin(9600);

  lcd.init();
  lcd.backlight();

  int status = WL_IDLE_STATUS;
  while (status != WL_CONNECTED) {
    Serial.print("Arduino UNO R4 - Attempting to connect to SSID: ");
    Serial.println(WIFI_SSID);
    // Connect to WPA/WPA2 network. Change this line if using open or WEP network:
    status = WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    // wait 10 seconds for connection:
    delay(10000);
  }
  // print your board's IP address:
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  connectToMQTT();
}

void loop() {
  mqtt.loop();

}

void connectToMQTT() {
  // Connect to the MQTT broker
  mqtt.begin(MQTT_BROKER_ADRRESS, MQTT_PORT, network);

  // Create a handler for incoming messages
  mqtt.onMessage(messageReceived);

  Serial.print("Arduino UNO R4 - Connecting to MQTT broker");

  while (!mqtt.connect(MQTT_CLIENT_ID, MQTT_USERNAME, MQTT_PASSWORD)) {
    Serial.print(".");
    delay(100);
  }
  Serial.println();

  if (!mqtt.connected()) {
    Serial.println("Arduino UNO R4 - MQTT broker Timeout!");
    return;
  }

  // Subscribe to a topic, the incoming messages are processed by messageHandler() function
  if (mqtt.subscribe(SUBSCRIBE_TOPIC))
    Serial.print("Arduino UNO R4 - Subscribed to the topic: ");
  else
    Serial.print("Arduino UNO R4 - Failed to subscribe to the topic: ");

  Serial.println(SUBSCRIBE_TOPIC);
  Serial.println("Arduino UNO R4 - MQTT broker Connected!");
}

void messageReceived(String &topic, String &payload) {
  Serial.println("Arduino UNO R4 - received from MQTT:");
  Serial.println("- topic: " + topic);
  Serial.println("- payload:");
  Serial.println(payload);

  // You can process the incoming data , then control something
  printWithWrap(payload);

}

// ประกาศตัวแปรระดับ Global ไว้บนหัวโค้ดเพื่อจำตำแหน่งล่าสุด
int lcdCol = 0;
int lcdRow = 0;

void printWithWrap(String message) {
  // วนลูปอ่านตัวอักษรในข้อความทีละตัว
  for (int idx = 0; idx < message.length(); idx++) {
    char ch = message[idx];

    if(message == "C"){
      lcd.clear();
      lcdCol = 0;
      lcdRow = 0;
      lcd.setCursor(lcdCol, lcdRow);
      return;
    }

    // 1. ตรวจสอบว่าคอลัมน์เต็ม 16 ช่องหรือยัง (0 ถึง 15)
    if (lcdCol > 15) {
      lcdCol = 0;   // กลับไปเริ่มคอลัมน์แรกสุด
      lcdRow++;     // ขึ้นแถวใหม่ (จากแถว 0 เป็นแถว 1)
    }

    // 2. ตรวจสอบว่าพิมพ์เกินบรรทัดที่จอรองรับหรือยัง (เกินแถวที่ 1)
    if (lcdRow > 1) {
      lcd.clear();  // เคลียร์หน้าจอทั้งหมดเพื่อเริ่มพิมพ์ใหม่
      lcdRow = 0;   // รีเซ็ตกลับไปแถวแรกสุด (บรรทัดบน)
      lcdCol = 0;   // รีเซ็ตคอลัมน์
    }

    // 3. ย้ายเคอร์เซอร์ไปยังตำแหน่งที่คำนวณได้ แล้วพิมพ์อักษรตัวนั้นลงไป
    lcd.setCursor(lcdCol, lcdRow);
    lcd.print(ch);

    lcdCol++; // ขยับตำแหน่งคอลัมน์ถัดไปสำหรับตัวอักษรตัวต่อไป
  }
}


