

void setup(){
  
  Serial.begin(9600);
  pinMode(2, OUTPUT);
  pinMode(4, INPUT);
  
}

void loop() {
  
  digitalWrite(2, HIGH);
  delayMicroseconds(10);
  digitalWrite(2, LOW);
  
  double pulseWidth = pulseIn(4, HIGH);
  double length = (0.0340) * pulseWidth/2;

  Serial.println(length);
  delay(400);
}